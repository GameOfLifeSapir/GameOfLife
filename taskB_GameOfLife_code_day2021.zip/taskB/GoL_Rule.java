package taskB;


/**
 * 
 * @author 
 * This class implements the CA rule for a standard 'Game of Life' simulation
 *
 */
public class GoL_Rule implements CA_Rule
{

	@Override
	public void ImplementRule()
	{
		// TODO Auto-generated method stub

	}

}
