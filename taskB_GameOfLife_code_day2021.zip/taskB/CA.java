package taskB;

/**
 * 
 * @author
 * Abstract class for cellular automata (CAs)
 *
 */
public abstract class CA implements Iterable
{
	// TODO add code as appropriate.
	// TODO Move code from GoL as appropriate.
}
