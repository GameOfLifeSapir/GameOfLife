package taskB;

/**
 * 
 * @author 
 * Interface for
 */
public interface CA_Rule
{
	abstract public void ImplementRule();
}
